# Minecraft Add-on Helfer

Kleine Android-App für Minecraft Bedrock. Sie merkt sich nach einmaliger Freigabe den Download-Ordner, sucht beim Öffnen automatisch das neueste Add-on und übergibt es an Minecraft.

## Unterstützte Dateien

- `.mcaddon`
- `.mcpack`
- `.mcworld`
- `.mctemplate`
- `.zip` (wird anhand des Inhalts als Minecraft-Datei aufbereitet)

## Bedienung

1. App installieren und öffnen.
2. Einmalig **Download-Ordner auswählen** und den normalen Download-Ordner bestätigen.
3. Künftig Add-on herunterladen und nur noch die App öffnen.
4. Minecraft startet und zeigt die Import-Bestätigung.

Die App verschiebt keine Dateien in geschützte Minecraft-Ordner. Sie nutzt den offiziellen Android-Dateizugriff und übergibt die Datei an Minecraft, das den eigentlichen Import ausführt.
