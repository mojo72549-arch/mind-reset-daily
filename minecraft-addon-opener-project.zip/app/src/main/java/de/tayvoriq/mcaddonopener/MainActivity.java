package de.tayvoriq.mcaddonopener;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class MainActivity extends Activity {
    private static final int REQUEST_TREE = 1001;
    private static final int REQUEST_FILE = 1002;
    private static final String PREFS = "settings";
    private static final String KEY_DOWNLOAD_TREE = "download_tree";
    private static final String MINECRAFT_PACKAGE = "com.mojang.minecraftpe";
    private static final String PROVIDER_AUTHORITY = "de.tayvoriq.mcaddonopener.files";
    private static final long MAX_COPY_BYTES = 1_000_000_000L;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView statusView;
    private ProgressBar progressBar;
    private Button importLatestButton;
    private Button chooseFolderButton;
    private Button chooseFileButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        handleIntent(getIntent(), true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent, false);
    }

    private void buildUi() {
        int padding = dp(22);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(244, 247, 242));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(padding, dp(34), padding, dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        TextView badge = new TextView(this);
        badge.setText("BEDROCK • ANDROID");
        badge.setTextSize(12);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(Color.rgb(60, 133, 39));
        badge.setGravity(Gravity.CENTER);
        root.addView(badge, fullWidth(dp(8)));

        TextView title = new TextView(this);
        title.setText("Minecraft Add-on\nHelfer");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.rgb(28, 32, 27));
        title.setGravity(Gravity.CENTER);
        root.addView(title, fullWidth(dp(12)));

        TextView subtitle = new TextView(this);
        subtitle.setText("Einmal den Download-Ordner auswählen. Danach reicht: Add-on herunterladen → App öffnen → Minecraft importiert es.");
        subtitle.setTextSize(17);
        subtitle.setTextColor(Color.rgb(75, 82, 73));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLineSpacing(0f, 1.15f);
        root.addView(subtitle, fullWidth(dp(26)));

        progressBar = new ProgressBar(this);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        progressParams.bottomMargin = dp(14);
        root.addView(progressBar, progressParams);

        statusView = new TextView(this);
        statusView.setText("Bereit. Beim ersten Start bitte einmal den Download-Ordner festlegen.");
        statusView.setTextSize(16);
        statusView.setTextColor(Color.rgb(35, 43, 33));
        statusView.setGravity(Gravity.CENTER);
        statusView.setBackgroundColor(Color.WHITE);
        statusView.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.addView(statusView, fullWidth(dp(18)));

        importLatestButton = createButton("Neuestes Add-on installieren", true);
        importLatestButton.setOnClickListener(v -> importNewestFromSavedFolder());
        root.addView(importLatestButton, fullWidth(dp(12)));

        chooseFolderButton = createButton("Download-Ordner einmalig auswählen", false);
        chooseFolderButton.setOnClickListener(v -> chooseDownloadFolder());
        root.addView(chooseFolderButton, fullWidth(dp(10)));

        chooseFileButton = createButton("Add-on-Datei manuell auswählen", false);
        chooseFileButton.setOnClickListener(v -> chooseFile());
        root.addView(chooseFileButton, fullWidth(dp(20)));

        TextView supported = new TextView(this);
        supported.setText("Unterstützt: .mcaddon, .mcpack, .mcworld, .mctemplate und passende .zip-Dateien. Keine Werbung, kein Konto, keine Datenübertragung.");
        supported.setTextSize(13);
        supported.setTextColor(Color.rgb(90, 97, 88));
        supported.setGravity(Gravity.CENTER);
        supported.setLineSpacing(0f, 1.15f);
        root.addView(supported, fullWidth(0));

        setContentView(scroll);
    }

    private Button createButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(16);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setMinHeight(dp(56));
        if (primary) {
            button.setTextColor(Color.WHITE);
            button.setBackgroundColor(Color.rgb(60, 133, 39));
        } else {
            button.setTextColor(Color.rgb(35, 43, 33));
            button.setBackgroundColor(Color.WHITE);
        }
        return button;
    }

    private LinearLayout.LayoutParams fullWidth(int bottomMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = bottomMargin;
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void handleIntent(Intent intent, boolean autoScanWhenNormalLaunch) {
        if (intent == null) {
            return;
        }

        Uri incoming = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            incoming = intent.getData();
        } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            incoming = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }

        if (incoming != null) {
            importUri(incoming, null);
            return;
        }

        if (autoScanWhenNormalLaunch) {
            SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
            if (preferences.contains(KEY_DOWNLOAD_TREE)) {
                importNewestFromSavedFolder();
            }
        }
    }

    private void chooseDownloadFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_TREE);
    }

    private void chooseFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/octet-stream",
                "application/zip",
                "application/x-zip-compressed"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }

        Uri uri = data.getData();
        if (requestCode == REQUEST_TREE) {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getSharedPreferences(PREFS, MODE_PRIVATE)
                        .edit().putString(KEY_DOWNLOAD_TREE, uri.toString()).apply();
                setStatus("Download-Ordner gespeichert. Suche nach dem neuesten Add-on …", true);
                importNewestFromSavedFolder();
            } catch (SecurityException exception) {
                showError("Der Ordnerzugriff konnte nicht dauerhaft gespeichert werden.");
            }
        } else if (requestCode == REQUEST_FILE) {
            importUri(uri, null);
        }
    }

    private void importNewestFromSavedFolder() {
        String tree = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_DOWNLOAD_TREE, null);
        if (tree == null) {
            setStatus("Beim ersten Mal bitte den Download-Ordner auswählen.", false);
            chooseDownloadFolder();
            return;
        }

        setBusy(true, "Suche das neueste Add-on im Download-Ordner …");
        Uri treeUri = Uri.parse(tree);
        executor.execute(() -> {
            try {
                DocumentCandidate candidate = findNewestSupportedDocument(treeUri);
                if (candidate == null) {
                    runOnUiThread(() -> {
                        setBusy(false, "Kein Add-on gefunden. Lade zuerst eine .mcaddon-, .mcpack- oder .mcworld-Datei herunter.");
                    });
                    return;
                }
                runOnUiThread(() -> importUri(candidate.uri, candidate.name));
            } catch (Exception exception) {
                runOnUiThread(() -> showError("Der Download-Ordner konnte nicht gelesen werden. Wähle ihn bitte erneut aus."));
            }
        });
    }

    private DocumentCandidate findNewestSupportedDocument(Uri treeUri) throws Exception {
        String rootDocumentId = DocumentsContract.getTreeDocumentId(treeUri);
        Deque<FolderLevel> queue = new ArrayDeque<>();
        queue.add(new FolderLevel(rootDocumentId, 0));
        DocumentCandidate newest = null;
        ContentResolver resolver = getContentResolver();

        while (!queue.isEmpty()) {
            FolderLevel folder = queue.removeFirst();
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, folder.documentId);
            String[] projection = {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                    DocumentsContract.Document.COLUMN_SIZE
            };

            try (Cursor cursor = resolver.query(childrenUri, projection, null, null, null)) {
                if (cursor == null) {
                    continue;
                }
                int idIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int typeIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE);
                int modifiedIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED);
                int sizeIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);

                while (cursor.moveToNext()) {
                    String documentId = cursor.getString(idIndex);
                    String name = cursor.getString(nameIndex);
                    String mime = cursor.getString(typeIndex);
                    long modified = modifiedIndex >= 0 && !cursor.isNull(modifiedIndex)
                            ? cursor.getLong(modifiedIndex) : 0L;
                    long size = sizeIndex >= 0 && !cursor.isNull(sizeIndex)
                            ? cursor.getLong(sizeIndex) : -1L;

                    if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                        if (folder.depth < 3) {
                            queue.addLast(new FolderLevel(documentId, folder.depth + 1));
                        }
                        continue;
                    }

                    if (size > MAX_COPY_BYTES || !isSupportedName(name)) {
                        continue;
                    }
                    Uri documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId);
                    if (newest == null || modified > newest.modified) {
                        newest = new DocumentCandidate(documentUri, name, modified);
                    }
                }
            }
        }
        return newest;
    }

    private boolean isSupportedName(String name) {
        if (name == null) {
            return false;
        }
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".mcaddon")
                || lower.endsWith(".mcpack")
                || lower.endsWith(".mcworld")
                || lower.endsWith(".mctemplate")
                || lower.endsWith(".zip");
    }

    private void importUri(Uri sourceUri, String knownName) {
        setBusy(true, "Bereite das Add-on für Minecraft vor …");
        executor.execute(() -> {
            try {
                String displayName = knownName != null ? knownName : queryDisplayName(sourceUri);
                if (displayName == null || displayName.trim().isEmpty()) {
                    displayName = "minecraft-addon.mcaddon";
                }
                if (!isSupportedName(displayName)) {
                    throw new IllegalArgumentException("Die Datei ist kein unterstütztes Minecraft-Add-on.");
                }

                File output = copyIntoPrivateCache(sourceUri, displayName);
                Uri shareUri = new Uri.Builder()
                        .scheme(ContentResolver.SCHEME_CONTENT)
                        .authority(PROVIDER_AUTHORITY)
                        .appendPath(output.getName())
                        .build();

                runOnUiThread(() -> launchMinecraft(shareUri, output.getName()));
            } catch (IllegalArgumentException exception) {
                runOnUiThread(() -> showError(exception.getMessage()));
            } catch (Exception exception) {
                runOnUiThread(() -> showError("Die Datei konnte nicht vorbereitet werden. Versuche die manuelle Dateiauswahl."));
            }
        });
    }

    private String queryDisplayName(Uri uri) {
        if (uri == null) {
            return null;
        }
        if (ContentResolver.SCHEME_FILE.equals(uri.getScheme())) {
            return uri.getLastPathSegment();
        }
        try (Cursor cursor = getContentResolver().query(
                uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    return cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        }
        return uri.getLastPathSegment();
    }

    private File copyIntoPrivateCache(Uri sourceUri, String originalName) throws Exception {
        File directory = new File(getCacheDir(), "imports");
        if (!directory.exists() && !directory.mkdirs()) {
            throw new IllegalStateException("Cache directory could not be created");
        }
        cleanOldCache(directory);

        String safeBase = sanitizeBaseName(originalName);
        String extension = extensionOf(originalName);
        String temporaryName = safeBase + "-" + UUID.randomUUID().toString().substring(0, 8)
                + (extension.isEmpty() ? ".mcaddon" : extension);
        File temporary = new File(directory, temporaryName);

        long total = 0L;
        try (InputStream raw = getContentResolver().openInputStream(sourceUri);
             BufferedInputStream input = new BufferedInputStream(raw != null ? raw : missingStream());
             BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(temporary))) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_COPY_BYTES) {
                    throw new IllegalArgumentException("Die Datei ist größer als 1 GB und wird nicht verarbeitet.");
                }
                output.write(buffer, 0, read);
            }
        }

        if (total == 0L) {
            throw new IllegalArgumentException("Die Datei ist leer.");
        }

        if (".zip".equalsIgnoreCase(extension)) {
            String detected = detectMinecraftExtension(temporary);
            File renamed = new File(directory, safeBase + "-"
                    + UUID.randomUUID().toString().substring(0, 8) + detected);
            if (!temporary.renameTo(renamed)) {
                throw new IllegalStateException("Datei konnte nicht umbenannt werden");
            }
            return renamed;
        }
        return temporary;
    }

    private InputStream missingStream() {
        throw new IllegalArgumentException("Die Datei konnte nicht geöffnet werden.");
    }

    private String detectMinecraftExtension(File zipFile) {
        boolean hasNestedPack = false;
        boolean hasNestedWorld = false;
        int manifestCount = 0;
        int inspected = 0;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(
                new java.io.FileInputStream(zipFile)))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null && inspected < 5000) {
                inspected++;
                String name = entry.getName().toLowerCase(Locale.ROOT);
                if (name.endsWith(".mcpack")) {
                    hasNestedPack = true;
                } else if (name.endsWith(".mcworld")) {
                    hasNestedWorld = true;
                } else if (name.endsWith("manifest.json")) {
                    manifestCount++;
                }
            }
        } catch (Exception ignored) {
            return ".mcaddon";
        }
        if (hasNestedWorld) {
            return ".mcworld";
        }
        if (hasNestedPack || manifestCount > 1) {
            return ".mcaddon";
        }
        return ".mcpack";
    }

    private String sanitizeBaseName(String name) {
        String withoutExtension = name;
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            withoutExtension = name.substring(0, dot);
        }
        String safe = withoutExtension.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (safe.isEmpty()) {
            safe = "minecraft-addon";
        }
        return safe.length() > 80 ? safe.substring(0, 80) : safe;
    }

    private String extensionOf(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : "";
    }

    private void cleanOldCache(File directory) {
        File[] files = directory.listFiles();
        if (files == null) {
            return;
        }
        long cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
        for (File file : files) {
            if (file.isFile() && file.lastModified() < cutoff) {
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            }
        }
    }

    private void launchMinecraft(Uri uri, String fileName) {
        grantUriPermission(MINECRAFT_PACKAGE, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);

        Intent[] attempts = new Intent[]{
                buildViewIntent(uri, "application/octet-stream", true),
                buildViewIntent(uri, "application/zip", true),
                buildViewIntent(uri, null, true),
                buildSendIntent(uri, true)
        };

        for (Intent attempt : attempts) {
            try {
                startActivity(attempt);
                setBusy(false, "Minecraft wurde geöffnet. Dort erscheint gleich die Import-Bestätigung für „" + fileName + "“.");
                return;
            } catch (ActivityNotFoundException ignored) {
            }
        }

        try {
            Intent generic = buildViewIntent(uri, "application/octet-stream", false);
            startActivity(Intent.createChooser(generic, "Add-on mit Minecraft öffnen"));
            setBusy(false, "Wähle im angezeigten Fenster Minecraft aus.");
        } catch (ActivityNotFoundException exception) {
            showError("Minecraft Bedrock ist auf diesem Gerät nicht installiert oder kann die Datei nicht öffnen.");
        }
    }

    private Intent buildViewIntent(Uri uri, String mimeType, boolean explicitMinecraft) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        if (mimeType == null) {
            intent.setData(uri);
        } else {
            intent.setDataAndType(uri, mimeType);
        }
        intent.setClipData(ClipData.newRawUri("Minecraft Add-on", uri));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (explicitMinecraft) {
            intent.setPackage(MINECRAFT_PACKAGE);
        }
        return intent;
    }

    private Intent buildSendIntent(Uri uri, boolean explicitMinecraft) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.setClipData(ClipData.newRawUri("Minecraft Add-on", uri));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (explicitMinecraft) {
            intent.setPackage(MINECRAFT_PACKAGE);
        }
        return intent;
    }

    private void setBusy(boolean busy, String message) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        importLatestButton.setEnabled(!busy);
        chooseFolderButton.setEnabled(!busy);
        chooseFileButton.setEnabled(!busy);
        setStatus(message, busy);
    }

    private void setStatus(String message, boolean active) {
        statusView.setText(message);
        statusView.setTextColor(active ? Color.rgb(45, 105, 31) : Color.rgb(35, 43, 33));
    }

    private void showError(String message) {
        setBusy(false, message != null ? message : "Unbekannter Fehler");
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private static final class DocumentCandidate {
        final Uri uri;
        final String name;
        final long modified;

        DocumentCandidate(Uri uri, String name, long modified) {
            this.uri = uri;
            this.name = name;
            this.modified = modified;
        }
    }

    private static final class FolderLevel {
        final String documentId;
        final int depth;

        FolderLevel(String documentId, int depth) {
            this.documentId = documentId;
            this.depth = depth;
        }
    }
}
